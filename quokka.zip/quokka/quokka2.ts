import value from './myModule';
import value2 = require("./myModule");
console.log(value);

import Ob = require('rxjs/Observable');
console.log("---------- :", typeof Ob["Observable"]);
console.log("-----:", Ob);
for(let k in Ob){
    console.log(k);
}
console.log(Ob.Observable.create());

for(let k in Ob.Observable.create()){
    console.log("Observable内部key: ",k);
}


var a = { b: 123 }
console.log(a);
console.log(a.b += 5);


let ps = "";
for (let a = 0; a < 100; a++) {
    ps += "1";/*?.*/
}


import leftPad = require('left-pad');
// const value = require('./myModule');
console.log(leftPad(1, 20, '0') + 1);